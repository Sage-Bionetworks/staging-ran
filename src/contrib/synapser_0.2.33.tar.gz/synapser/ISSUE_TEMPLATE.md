## Operating system

*Which operating system are you working on? E.g., Ubuntu Linux, Max OSX, Windows 10, etc.*

## Description of the problem

*Provide a description of the problem, and if possible a minimal reproducible example.*

### Expected behavior

*What did you expect to happen?*

### Actual behavior

*What actually happened? Provide output or error messages from the console, if applicable.*

## Output of `sessionInfo()`

*Copy the output of running `sessionInfo()` to get a listing of your R environment.*
