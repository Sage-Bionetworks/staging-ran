#ifndef PYTHONINR_FUNCTIONS
#define PYTHONINR_FUNCTIONS
#include "PythonInR.h"
#include "CastRObjects.h"
#include "CastPyObjects.h"
#include <R_ext/Parse.h>
#endif

