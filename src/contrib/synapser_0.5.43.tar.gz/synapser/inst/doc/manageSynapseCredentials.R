## ----collapse = TRUE, eval = F-------------------------------------------
#  library("synapser")
#  synLogin("username", "password")

## ----collapse = TRUE, eval = F-------------------------------------------
#  [authentication]
#  username = your_username
#  password = your_password
#  

## ----collapse = TRUE, eval = F-------------------------------------------
#  library("synapser")
#  synLogin()

## ----collapse = TRUE, eval = F-------------------------------------------
#  library("synapser")
#  synLogin("username", "password", rememberMe=True)

## ----collapse = TRUE, eval = F-------------------------------------------
#  library("synapser")
#  synLogin()

