#include <R_ext/Utils.h>
#include <signal.h>
#include "PythonInR.h"

void chkIntFn(void *dummy);

int checkInterrupt();
