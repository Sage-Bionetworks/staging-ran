## ----collapse=TRUE-------------------------------------------------------
library(synapser)
synLogin()
# Create a new project
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)

# Create some files
filePath<- tempfile()
connection<-file(filePath)
writeChar("this is the content of the first file", connection, eos=NULL)
close(connection)  
file <- File(path=filePath, parent=project)
file <- synStore(file)

filePath2<- tempfile()
connection2<-file(filePath2)
writeChar("this is the content of the second file", connection, eos=NULL)
close(connection2)  
file2 <- File(path=filePath2, parent=project)
file2 <- synStore(file2)

# add some annotations
synSetAnnotations(file, list(contributor="Sage", class="V"))
synSetAnnotations(file2, list(contributor="UW", rank="X"))

## ----collapse=TRUE-------------------------------------------------------
view <- EntityViewSchema(name='my first file view',
                         parent=project$properties$id,
                         scopes=c(project$properties$id))

view <- synStore(view)

## ----include = FALSE-----------------------------------------------------
# wait for the view to be created
Sys.sleep(10)

## ----collapse=TRUE-------------------------------------------------------
queryResults <- synTableQuery(sprintf("select * from %s", view$properties$id))
data <- as.data.frame(queryResults)
data

## ----collapse=TRUE-------------------------------------------------------
sprintf("https://www.synapse.org/#!Synapse:%s", view$properties$id)

## ----collapse=TRUE, eval=F-----------------------------------------------
#  queryResults <- synTableQuery(sprintf("select * from %s", view$properties$id))
#  data <- as.data.frame(queryResults)
#  data

## ----collapse=TRUE, eval=F-----------------------------------------------
#  data['class'] = c('V', 'VI')
#  synStore(Table(view$properties$id, data))

## ----collapse=TRUE, eval=F-----------------------------------------------
#  synGetAnnotations(file2$properties$id)

## ----collapse=TRUE-------------------------------------------------------
synDelete(project)

