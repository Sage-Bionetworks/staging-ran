## ----eval=F--------------------------------------------------------------
#  install.packages("synapser", repos=c("https://sage-bionetworks.github.io/drat", "https://cran.cnr.berkeley.edu/"))

## ----eval=F--------------------------------------------------------------
#  options(repos=c("https://sage-bionetworks.github.io/drat", "https://cran.cnr.berkeley.edu/"))

## ----eval=F--------------------------------------------------------------
#  install.packages("synapser")

## ----eval=F--------------------------------------------------------------
#  library(synapser)
#  synLogin('me@nowhere.com', 'secret')

## ----collapse=TRUE-------------------------------------------------------
library(synapser)
synLogin()

## ----eval=F--------------------------------------------------------------
#  ?synLogin
#  ?synLogout

## ----collapse=TRUE-------------------------------------------------------
entity <- synGet('syn1899498')

## ----collapse=TRUE-------------------------------------------------------
print(entity)

## ----collapse=TRUE-------------------------------------------------------
read.table(entity$path)

## ----eval=F, collapse=TRUE-----------------------------------------------
#  synOnweb('syn1899498')

## ----eval=F--------------------------------------------------------------
#  ?synGet
#  ?synOnweb

## ----collapse=TRUE-------------------------------------------------------
# (We use a time stamp in this example just to help ensure uniqueness.)
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)

## ----collapse=TRUE-------------------------------------------------------
dataFolder <- Folder('Data', parent=project)
dataFolder <- synStore(dataFolder)

## ----collapse=TRUE-------------------------------------------------------
filePath<- tempfile()
connection<-file(filePath)
writeChar("this is the content of the file", connection, eos=NULL)
close(connection)  
file <- File(path=filePath, parent=dataFolder)
file <- synStore(file)

## ----collapse=TRUE-------------------------------------------------------
file$properties

## ----collapse=TRUE-------------------------------------------------------
file$properties$name<-"different name"

## ----collapse=TRUE-------------------------------------------------------
file<-synStore(file)
file$properties

## ----collapse=TRUE-------------------------------------------------------
synDelete(file)

## ----collapse=TRUE-------------------------------------------------------
folderId<-dataFolder$properties$id
synDelete(project)
tryCatch(
	synGet(folderId),
	error=function(e) {
		message(sprintf("Retrieving a deleted folder causes: %s", as.character(e)))
	},
	silent = TRUE
)

## ----eval=F--------------------------------------------------------------
#  ?Project
#  ?Folder
#  ?File
#  ?Link
#  ?synStore

## ----collapse=TRUE-------------------------------------------------------
# (We use a time stamp just to help ensure uniqueness.)
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)

## ----collapse=TRUE-------------------------------------------------------
synSetAnnotations(project, list(annotationName="annotationValue"))

project<-synGet(project$properties$id)

project$annotations

synGetAnnotations(project)

## ----collapse=TRUE-------------------------------------------------------

annotations<-synGetAnnotations(project)

annotations[["numeric_annotation_name"]]<-42

annotations<-synSetAnnotations(project, annotations)

annotations

## ----eval=F--------------------------------------------------------------
#  ?Activity

## ----eval=F--------------------------------------------------------------
#  ?Schema
#  ?Column
#  ?synGetColumns
#  ?synGetTableColumns

## ----eval=F--------------------------------------------------------------
#  ?synGetWiki
#  ?Wiki

## ----eval=F--------------------------------------------------------------
#  ?getEvaluation
#  ?submit
#  ?getSubmissions
#  ?getSubmission
#  ?getSubmissionStatus

## ----eval=F--------------------------------------------------------------
#  ?synGetPermissions
#  ?synSetPermissions

## ----collapse=TRUE-------------------------------------------------------
synDelete(project)

## ----eval=F--------------------------------------------------------------
#  ?synRestGET
#  ?synRestPOST
#  ?synRestPUT
#  ?synRestDELETE

