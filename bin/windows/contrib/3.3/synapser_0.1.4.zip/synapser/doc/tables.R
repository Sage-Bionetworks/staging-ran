## ----collapse=TRUE-------------------------------------------------------
library(synapser)
synLogin()
# Create a new project
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)


## ----collapse=TRUE-------------------------------------------------------
cols <- list(
    Column(name='Name', columnType='STRING', maximumSize=20),
    Column(name='Chromosome', columnType='STRING', maximumSize=20),
    Column(name='Start', columnType='INTEGER'),
    Column(name='End', columnType='INTEGER'),
    Column(name='Strand', columnType='STRING', enumValues=list('+', '-'), maximumSize=1),
    Column(name='TranscriptionFactor', columnType='BOOLEAN'))

schema <- Schema(name='My Favorite Genes', columns=cols, parent=project)

## ----collapse=TRUE-------------------------------------------------------
genes<-data.frame(
	Name=c("foo", "arg", "zap", "bah", "bnk", "xyz"), 
	Chromosome=c(1,2,2,1,1,1), 
	Start=c(12345,20001,30033,40444,51234,61234),
	End=c(126000,20200,30999,41444,54567,68686),
	Strand=c('+', '+', '-', '-', '+', '+'),
	TranscriptionFactor=c(F,F,F,F,T,F))
genesFile<-tempfile()
write.csv(genes, file=genesFile, row.names=FALSE)

## ----collapse=TRUE-------------------------------------------------------
table<-Table(schema, genesFile)
table<-synStore(table)
tableId<-table$schema$properties$id

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='1' and Start < 41000 and End > 20000", tableId))
results$asDataFrame()

## ----collapse=TRUE-------------------------------------------------------
more_genes<-data.frame(
	Name=c("abc", "def"), 
	Chromosome=c(2,2), 
	Start=c(12345,20001),
	End=c(126000,20200),
	Strand=c('+', '+'),
	TranscriptionFactor=c(F,F))
more_genes_file<-tempfile()
write.csv(more_genes, file=more_genes_file, row.names=FALSE)
synStore(Table(tableId, more_genes_file))

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='1'", tableId))
df <-results$asDataFrame(rowIdAndVersionInIndex=FALSE)
df['Name'] = c('rzing', 'zing1', 'zing2', 'zing3')
write.csv(df, results$filepath, row.names=FALSE)

## ----collapse=TRUE-------------------------------------------------------
table<-Table(tableId, results$filepath)
table<-synStore(table)

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s limit 10", tableId))
results$asDataFrame()

## ----collapse=TRUE-------------------------------------------------------
synDelete(project)

