#!C:\bin\R\bin\x64\Rscript.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'synapseclient==1.8.2','console_scripts','synapse'
__requires__ = 'synapseclient==1.8.2'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('synapseclient==1.8.2', 'console_scripts', 'synapse')()
    )
