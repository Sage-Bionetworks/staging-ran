## ----collapse=TRUE-------------------------------------------------------
library(synapser)
synLogin()
# Create a new project
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)


## ----collapse=TRUE-------------------------------------------------------
cols <- list(
    Column(name='Name', columnType='STRING', maximumSize=20),
    Column(name='Chromosome', columnType='STRING', maximumSize=20),
    Column(name='Start', columnType='INTEGER'),
    Column(name='End', columnType='INTEGER'),
    Column(name='Strand', columnType='STRING', enumValues=list('+', '-'), maximumSize=1),
    Column(name='TranscriptionFactor', columnType='BOOLEAN'))

schema <- Schema(name='My Favorite Genes', columns=cols, parent=project)

## ----collapse=TRUE-------------------------------------------------------
genes<-data.frame(
	Name=c("foo", "arg", "zap", "bah", "bnk", "xyz"), 
	Chromosome=c(1,2,2,1,1,1), 
	Start=c(12345,20001,30033,40444,51234,61234),
	End=c(126000,20200,30999,41444,54567,68686),
	Strand=c('+', '+', '-', '-', '+', '+'),
	TranscriptionFactor=c(F,F,F,F,T,F))
genesFile<-tempfile()
saveToCsv(genes, genesFile)

## ----collapse=TRUE-------------------------------------------------------
table<-Table(schema, genesFile)
table<-synStore(table)
tableId<-table$schema$properties$id

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='1' and Start < 41000 and End > 20000", tableId))
results$asDataFrame()

## ----collapse=TRUE-------------------------------------------------------
moreGenes<-data.frame(
	Name=c("abc", "def"), 
	Chromosome=c(2,2), 
	Start=c(12345,20001),
	End=c(126000,20200),
	Strand=c('+', '+'),
	TranscriptionFactor=c(F,F))
moreGenesFile<-tempfile()
saveToCsv(moreGenes, moreGenesFile)
synStore(Table(tableId, moreGenesFile))

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='1'", tableId))
df <-results$asDataFrame()
df['Name'] = c('rzing', 'zing1', 'zing2', 'zing3')

## ----collapse=TRUE-------------------------------------------------------
saveToCsv(df, results$filepath)
table<-Table(tableId, results$filepath)
table<-synStore(table)

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s limit 10", tableId))
results$asDataFrame()

## ----collapse=TRUE-------------------------------------------------------
schema <- synGet(tableId)
newColumn <- synStore(Column(name='Note', columnType='STRING', maximumSize=20))
schema$addColumn(newColumn)
schema <- synStore(schema)

## ----collapse=TRUE-------------------------------------------------------
schema$removeColumn(newColumn)
notesColumn <- synStore(Column(name='Notes', columnType='STRING', maximumSize=20))
schema$addColumn(notesColumn)
schema <- synStore(schema)

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("SELECT * FROM %s", tableId))
data <- results$asDataFrame()
data['Notes'] = c("check name",NA,NA,NA,"update test",NA,NA,NA)
saveToCsv(data, results$filepath)
synStore(Table(tableId, results$filepath))

## ----collapse=TRUE-------------------------------------------------------
# getting the existing table metadata and data
originalSchema <- synGet(tableId)
oldQueryResults <- synTableQuery(sprintf("SELECT * FROM %s", tableId))
oldData <- oldQueryResults$asDataFrame()

# remove the column
originalSchema$removeColumn(notesColumn)
newSchema <- synStore(originalSchema)

# create a new Column
newCol <- Column(name='Notes', columnType='STRING', maximumSize=100)

# add the new column to the new table
newSchema$addColumn(newCol)
newSchema <- synStore(newSchema)

# copy the data over to the new column
newQueryResults <- synTableQuery(sprintf("SELECT * FROM %s", newSchema$properties$id))
newData <- newQueryResults$asDataFrame()
newData['Notes'] <- oldData['Notes']

# save the change
saveToCsv(newData, newQueryResults$filepath)
synStore(Table(tableId, newQueryResults$filepath))

# add the new data
moreGenes<-data.frame(
    Name=c("not_sure"), 
    Chromosome=c(2), 
    Start=c(12345),
    End=c(126000),
    Strand=c('+'),
    TranscriptionFactor=c(F),
    Notes=c('a very looooooooong note'))
moreGenesFile<-tempfile()
saveToCsv(moreGenes, moreGenesFile)
synStore(Table(tableId, moreGenesFile))

## ----collapse=TRUE, eval=F-----------------------------------------------
#  # example depends on synapseclient.uploadSynapseManagedFileHandle()
#  # and not available until python client 1.7.3 is released
#  newCols <- list(
#      Column(name='artist', columnType='STRING', maximumSize=50),
#      Column(name='album', columnType='STRING', maximumSize=50),
#      Column(name='year', columnType='INTEGER'),
#      Column(name='catalog', columnType='STRING', maximumSize=50),
#      Column(name='cover', columnType='FILEHANDLEID'))
#  newSchema <- synStore(Schema(name='Jazz Albums', columns=newCols, parent=project))
#  
#  newData <- data.frame(
#    artist = c("John Coltrane", "Sonny Rollins", "Sonny Rollins", "Kenny Burrel"),
#    album = c("Blue Train", "Vol. 2", "Newk's Time", "Kenny Burrel"),
#    year = c(1957, 1957, 1958, 1956),
#    catalog = c("BLP 1577", "BLP 1558", "BLP 4001", "BLP 1543")
#  )
#  
#  # writing some temp files to upload or pointing to existing files in your system
#  
#  files <- c("coltraneBlueTrain.jpg", "rollinsBN1558.jpg", "rollinsBN4001.jpg", "burrellWarholBN1543.jpg")
#  
#  # upload to filehandle service
#  files <- lapply(files, function (f) {
#    temp_file <- tempfile(f)
#    write(f, file=temp_file)
#    synUploadSynapseManagedFileHandle(f)
#    })
#  # get the filehandle ids
#  fileHandleIds <- sapply(files, function(f) f[1]$id)
#  newData["covers"] <- fileHandleIds
#  
#  tempFile<-tempfile()
#  saveToCsv(newData, file=tempFile)
#  synStore(Table(newSchema$properties$id, tempFile))

## ----collapse=TRUE-------------------------------------------------------
schema <- synGet(tableId)
synSetAnnotations(schema, list(category="test"))

## ----collapse=TRUE-------------------------------------------------------
schema <- synGet(tableId)
schema$annotations

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='2'", tableId))
deleted <- synDelete(results$asRowSet())

## ----collapse=TRUE-------------------------------------------------------
synDelete(schema)

## ----eval=F--------------------------------------------------------------
#  ?Schema
#  ?Column
#  ?Row
#  ?Table

## ----collapse=TRUE-------------------------------------------------------
synDelete(project)

